import { createFileRoute } from "@tanstack/react-router";
import { FallingGame } from "@/components/game/falling-game";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FALLOUT — Shoot or Block Falling Debris" },
      {
        name: "description",
        content:
          "Arcade survival: shoot or block 100 kinds of falling debris, chase rare drops, and stack 20 tiered upgrades.",
      },
      { property: "og:title", content: "FALLOUT — Shoot or Block" },
      {
        property: "og:description",
        content:
          "Arcade survival: blast falling debris, farm rare drops, and stack 20 tiered upgrades.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="min-h-[100dvh] bg-background">
      <FallingGame />
    </main>
  );
}
