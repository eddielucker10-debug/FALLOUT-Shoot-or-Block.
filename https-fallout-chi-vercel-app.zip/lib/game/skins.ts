export interface Skin {
  id: string
  name: string
  /** coin cost to unlock (0 = free / owned by default) */
  cost: number
  /** main hull fill color */
  body: string
  /** glow / shadow color */
  glow: string
  /** cockpit color */
  cockpit: string
  /** thruster flame color */
  thruster: string
}

/** The default ship — always owned, free. */
export const DEFAULT_SKIN: Skin = {
  id: "standard",
  name: "Standard Issue",
  cost: 0,
  body: "#c4b5fd",
  glow: "#a78bfa",
  cockpit: "#7c3aed",
  thruster: "#67e8f9",
}

// 20 unlockable skins. Prices start at 100,000 and climb by 50,000 each.
const SKIN_DEFS: Omit<Skin, "cost">[] = [
  { id: "ember", name: "Ember", body: "#fdba74", glow: "#f97316", cockpit: "#c2410c", thruster: "#fef08a" },
  { id: "toxic", name: "Toxic Bloom", body: "#bef264", glow: "#84cc16", cockpit: "#4d7c0f", thruster: "#ecfccb" },
  { id: "frostbite", name: "Frostbite", body: "#bae6fd", glow: "#38bdf8", cockpit: "#0369a1", thruster: "#e0f2fe" },
  { id: "voidwalker", name: "Voidwalker", body: "#c4b5fd", glow: "#7c3aed", cockpit: "#4c1d95", thruster: "#ddd6fe" },
  { id: "bloodmoon", name: "Blood Moon", body: "#fca5a5", glow: "#ef4444", cockpit: "#991b1b", thruster: "#fecaca" },
  { id: "goldrush", name: "Gold Rush", body: "#fde68a", glow: "#f59e0b", cockpit: "#b45309", thruster: "#fffbeb" },
  { id: "neonpulse", name: "Neon Pulse", body: "#f0abfc", glow: "#d946ef", cockpit: "#a21caf", thruster: "#fae8ff" },
  { id: "deepsea", name: "Deep Sea", body: "#5eead4", glow: "#14b8a6", cockpit: "#0f766e", thruster: "#ccfbf1" },
  { id: "sunburst", name: "Sunburst", body: "#fcd34d", glow: "#f97316", cockpit: "#ea580c", thruster: "#fef9c3" },
  { id: "amethyst", name: "Amethyst", body: "#d8b4fe", glow: "#a855f7", cockpit: "#6b21a8", thruster: "#f3e8ff" },
  { id: "chrome", name: "Chrome", body: "#e2e8f0", glow: "#94a3b8", cockpit: "#475569", thruster: "#f8fafc" },
  { id: "inferno", name: "Inferno", body: "#fca5a5", glow: "#f97316", cockpit: "#7f1d1d", thruster: "#fde047" },
  { id: "aurora", name: "Aurora", body: "#6ee7b7", glow: "#22d3ee", cockpit: "#0e7490", thruster: "#a7f3d0" },
  { id: "cobalt", name: "Cobalt", body: "#93c5fd", glow: "#2563eb", cockpit: "#1e3a8a", thruster: "#dbeafe" },
  { id: "rosequartz", name: "Rose Quartz", body: "#fbcfe8", glow: "#ec4899", cockpit: "#9d174d", thruster: "#fce7f3" },
  { id: "emerald", name: "Emerald", body: "#6ee7b7", glow: "#10b981", cockpit: "#065f46", thruster: "#d1fae5" },
  { id: "obsidian", name: "Obsidian", body: "#64748b", glow: "#22d3ee", cockpit: "#0f172a", thruster: "#67e8f9" },
  { id: "plasma", name: "Plasma", body: "#a5f3fc", glow: "#06b6d4", cockpit: "#155e75", thruster: "#ffffff" },
  { id: "solarflare", name: "Solar Flare", body: "#fed7aa", glow: "#fb923c", cockpit: "#9a3412", thruster: "#fef08a" },
  { id: "singularity", name: "Singularity", body: "#e9d5ff", glow: "#f472b6", cockpit: "#1e1b4b", thruster: "#f0abfc" },
]

export const SKINS: Skin[] = [
  DEFAULT_SKIN,
  ...SKIN_DEFS.map((s, i) => ({ ...s, cost: 100000 + i * 50000 })),
]

export function getSkin(id: string): Skin {
  return SKINS.find((s) => s.id === id) ?? DEFAULT_SKIN
}

// ---- Bullet skins ----

export interface BulletSkin {
  id: string
  name: string
  /** coin cost to unlock (0 = free / owned by default) */
  cost: number
  /** projectile core fill color */
  core: string
  /** glow / shadow color */
  glow: string
  /** color used when the shot is a critical hit */
  crit: string
}

/** The default tracer — always owned, free. */
export const DEFAULT_BULLET_SKIN: BulletSkin = {
  id: "tracer",
  name: "Standard Tracer",
  cost: 0,
  core: "#a5f3fc",
  glow: "#67e8f9",
  crit: "#fecdd3",
}

// 15 unlockable bullet skins. Prices start at 100,000 and climb by 50,000 each.
const BULLET_DEFS: Omit<BulletSkin, "cost">[] = [
  { id: "b-plasma", name: "Plasma Bolt", core: "#f0abfc", glow: "#d946ef", crit: "#fae8ff" },
  { id: "b-ember", name: "Ember Round", core: "#fdba74", glow: "#f97316", crit: "#fef08a" },
  { id: "b-toxic", name: "Toxic Dart", core: "#bef264", glow: "#84cc16", crit: "#ecfccb" },
  { id: "b-frost", name: "Frost Shard", core: "#bae6fd", glow: "#38bdf8", crit: "#e0f2fe" },
  { id: "b-blood", name: "Blood Tracer", core: "#fca5a5", glow: "#ef4444", crit: "#fecaca" },
  { id: "b-gold", name: "Golden Slug", core: "#fde68a", glow: "#f59e0b", crit: "#fffbeb" },
  { id: "b-void", name: "Void Lance", core: "#c4b5fd", glow: "#7c3aed", crit: "#ddd6fe" },
  { id: "b-aqua", name: "Aqua Pulse", core: "#5eead4", glow: "#14b8a6", crit: "#ccfbf1" },
  { id: "b-rose", name: "Rose Beam", core: "#fbcfe8", glow: "#ec4899", crit: "#fce7f3" },
  { id: "b-emerald", name: "Emerald Ray", core: "#6ee7b7", glow: "#10b981", crit: "#d1fae5" },
  { id: "b-cobalt", name: "Cobalt Streak", core: "#93c5fd", glow: "#2563eb", crit: "#dbeafe" },
  { id: "b-solar", name: "Solar Flare", core: "#fed7aa", glow: "#fb923c", crit: "#fef08a" },
  { id: "b-chrome", name: "Chrome Slug", core: "#e2e8f0", glow: "#94a3b8", crit: "#f8fafc" },
  { id: "b-neon", name: "Neon Bolt", core: "#a5f3fc", glow: "#06b6d4", crit: "#ffffff" },
  { id: "b-singularity", name: "Singularity Shot", core: "#e9d5ff", glow: "#f472b6", crit: "#f0abfc" },
]

export const BULLET_SKINS: BulletSkin[] = [
  DEFAULT_BULLET_SKIN,
  ...BULLET_DEFS.map((s, i) => ({ ...s, cost: 100000 + i * 50000 })),
]

export function getBulletSkin(id: string): BulletSkin {
  return BULLET_SKINS.find((s) => s.id === id) ?? DEFAULT_BULLET_SKIN
}
