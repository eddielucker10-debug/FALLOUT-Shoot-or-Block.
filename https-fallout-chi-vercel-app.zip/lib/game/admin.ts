// Admin / developer cheat system.
// Gated behind a password in the UI. Toggle powers feed a Cheats object the
// engine reads every frame; action powers fire one-off callbacks.

export const ADMIN_PASSWORD = "261112"

export interface Cheats {
  godMode: boolean
  infiniteShield: boolean
  instantShieldCd: boolean
  thorns: boolean
  noVolatile: boolean
  lifestealHit: boolean
  hyperRegen: boolean
  oneShot: boolean
  alwaysCrit: boolean
  infinitePierce: boolean
  giantBullets: boolean
  megaMultishot: boolean
  wideSpread: boolean
  rapidFire: boolean
  autoFire: boolean
  allExplosive: boolean
  homing: boolean
  freezeEnemies: boolean
  lowGravity: boolean
  noSpawns: boolean
  doubleSpawns: boolean
  fastWaves: boolean
  maxLuck: boolean
  rainbow: boolean
  bigPlayer: boolean
  tinyPlayer: boolean
  showHitboxes: boolean
  damageMult: number
  coinMult: number
  fireRateMult: number
  speedMult: number
  shieldMult: number
}

export const DEFAULT_CHEATS: Cheats = {
  godMode: false,
  infiniteShield: false,
  instantShieldCd: false,
  thorns: false,
  noVolatile: false,
  lifestealHit: false,
  hyperRegen: false,
  oneShot: false,
  alwaysCrit: false,
  infinitePierce: false,
  giantBullets: false,
  megaMultishot: false,
  wideSpread: false,
  rapidFire: false,
  autoFire: false,
  allExplosive: false,
  homing: false,
  freezeEnemies: false,
  lowGravity: false,
  noSpawns: false,
  doubleSpawns: false,
  fastWaves: false,
  maxLuck: false,
  rainbow: false,
  bigPlayer: false,
  tinyPlayer: false,
  showHitboxes: false,
  damageMult: 1,
  coinMult: 1,
  fireRateMult: 1,
  speedMult: 1,
  shieldMult: 1,
}

export type PowerGroup =
  | "Offense"
  | "Defense"
  | "Multipliers"
  | "Control"
  | "Visual"
  | "Economy"
  | "Unlocks"

export interface Power {
  id: string
  name: string
  desc: string
  kind: "toggle" | "action"
  group: PowerGroup
  /** action powers that only make sense during an active run */
  runOnly?: boolean
}

// 40 toggle powers + 10 action powers = 50 total.
export const POWERS: Power[] = [
  // --- Offense (toggles) ---
  { id: "oneShot", name: "One-Shot Kill", desc: "Every hit deals massive damage.", kind: "toggle", group: "Offense" },
  { id: "alwaysCrit", name: "Guaranteed Crits", desc: "Every shot is a critical hit.", kind: "toggle", group: "Offense" },
  { id: "infinitePierce", name: "Infinite Pierce", desc: "Shots pass through everything.", kind: "toggle", group: "Offense" },
  { id: "giantBullets", name: "Giant Bullets", desc: "Triple projectile size.", kind: "toggle", group: "Offense" },
  { id: "megaMultishot", name: "Mega Multishot", desc: "Fire 30 projectiles at once.", kind: "toggle", group: "Offense" },
  { id: "wideSpread", name: "Wide Spread", desc: "Blanket the whole screen.", kind: "toggle", group: "Offense" },
  { id: "rapidFire", name: "Hyper Fire Rate", desc: "Fire absurdly fast.", kind: "toggle", group: "Offense" },
  { id: "autoFire", name: "Auto-Fire", desc: "Shoot continuously, no input.", kind: "toggle", group: "Offense" },
  { id: "allExplosive", name: "Explosive Everything", desc: "All kills detonate.", kind: "toggle", group: "Offense" },
  { id: "homing", name: "Homing Bullets", desc: "Projectiles chase targets.", kind: "toggle", group: "Offense" },

  // --- Defense (toggles) ---
  { id: "godMode", name: "God Mode", desc: "Take no damage at all.", kind: "toggle", group: "Defense" },
  { id: "infiniteShield", name: "Infinite Shield", desc: "Shield never drains or breaks.", kind: "toggle", group: "Defense" },
  { id: "instantShieldCd", name: "Instant Shield Recharge", desc: "No shield cooldown.", kind: "toggle", group: "Defense" },
  { id: "thorns", name: "Thorns Aura", desc: "Damage clears the whole screen.", kind: "toggle", group: "Defense" },
  { id: "noVolatile", name: "Defuse Volatiles", desc: "Volatile debris deals normal damage.", kind: "toggle", group: "Defense" },
  { id: "lifestealHit", name: "Lifesteal Rounds", desc: "Heal on every projectile hit.", kind: "toggle", group: "Defense" },
  { id: "hyperRegen", name: "Hyper Regen", desc: "Regenerate hull very quickly.", kind: "toggle", group: "Defense" },

  // --- Multipliers (toggles) ---
  { id: "dmgX2", name: "Damage x2", desc: "Double all damage.", kind: "toggle", group: "Multipliers" },
  { id: "dmgX5", name: "Damage x5", desc: "5x all damage.", kind: "toggle", group: "Multipliers" },
  { id: "dmgX25", name: "Damage x25", desc: "25x all damage.", kind: "toggle", group: "Multipliers" },
  { id: "dmgX100", name: "Damage x100", desc: "100x all damage.", kind: "toggle", group: "Multipliers" },
  { id: "fireRateX2", name: "Fire Rate x2", desc: "Double fire rate.", kind: "toggle", group: "Multipliers" },
  { id: "fireRateX3", name: "Fire Rate x3", desc: "Triple fire rate.", kind: "toggle", group: "Multipliers" },
  { id: "speedX2", name: "Move Speed x2", desc: "Double movement speed.", kind: "toggle", group: "Multipliers" },
  { id: "speedX3", name: "Move Speed x3", desc: "Triple movement speed.", kind: "toggle", group: "Multipliers" },
  { id: "shieldX3", name: "Triple Shield Capacity", desc: "3x shield pool.", kind: "toggle", group: "Multipliers" },
  { id: "coinX2", name: "Coins x2", desc: "Double coins earned.", kind: "toggle", group: "Multipliers" },
  { id: "coinX5", name: "Coins x5", desc: "5x coins earned.", kind: "toggle", group: "Multipliers" },
  { id: "coinX25", name: "Coins x25", desc: "25x coins earned.", kind: "toggle", group: "Multipliers" },
  { id: "coinX100", name: "Coins x100", desc: "100x coins earned.", kind: "toggle", group: "Multipliers" },

  // --- Control (toggles) ---
  { id: "freezeEnemies", name: "Freeze Enemies", desc: "Debris stops falling.", kind: "toggle", group: "Control" },
  { id: "lowGravity", name: "Low Gravity", desc: "Debris falls at 40% speed.", kind: "toggle", group: "Control" },
  { id: "noSpawns", name: "Stop Spawns", desc: "No new debris appears.", kind: "toggle", group: "Control" },
  { id: "doubleSpawns", name: "Double Spawns", desc: "Twice the debris.", kind: "toggle", group: "Control" },
  { id: "fastWaves", name: "Fast Waves", desc: "Waves advance 3x faster.", kind: "toggle", group: "Control" },
  { id: "maxLuck", name: "Max Luck", desc: "Force the rarest spawns.", kind: "toggle", group: "Control" },

  // --- Visual (toggles) ---
  { id: "rainbow", name: "Rainbow Mode", desc: "Cycle projectile colors.", kind: "toggle", group: "Visual" },
  { id: "bigPlayer", name: "Giant Ship", desc: "Render an oversized ship.", kind: "toggle", group: "Visual" },
  { id: "tinyPlayer", name: "Tiny Ship", desc: "Render a miniature ship.", kind: "toggle", group: "Visual" },
  { id: "showHitboxes", name: "Show Hitboxes", desc: "Draw debris hit circles.", kind: "toggle", group: "Visual" },

  // --- Economy (actions) ---
  { id: "give1m", name: "Give 1,000,000 Coins", desc: "Add one million coins.", kind: "action", group: "Economy" },
  { id: "give10m", name: "Give 10,000,000 Coins", desc: "Add ten million coins.", kind: "action", group: "Economy" },
  { id: "give100m", name: "Give 100,000,000 Coins", desc: "Add a hundred million coins.", kind: "action", group: "Economy" },
  { id: "give1b", name: "Give 1,000,000,000 Coins", desc: "Add one billion coins.", kind: "action", group: "Economy" },
  { id: "resetCoins", name: "Reset Coins", desc: "Set your coin balance to zero.", kind: "action", group: "Economy" },

  // --- Unlocks (actions) ---
  { id: "unlockShips", name: "Unlock All Ship Skins", desc: "Grant every ship skin.", kind: "action", group: "Unlocks" },
  { id: "unlockBullets", name: "Unlock All Bullet Skins", desc: "Grant every bullet skin.", kind: "action", group: "Unlocks" },
  { id: "maxUpgrades", name: "Max All Upgrades", desc: "Set every upgrade to max tier.", kind: "action", group: "Unlocks" },
  { id: "resetUpgrades", name: "Reset All Upgrades", desc: "Clear every upgrade.", kind: "action", group: "Unlocks" },
  { id: "fullHeal", name: "Full Heal", desc: "Restore hull and shield now.", kind: "action", group: "Unlocks", runOnly: true },
]

export const TOGGLE_POWERS = POWERS.filter((p) => p.kind === "toggle")
export const ACTION_POWERS = POWERS.filter((p) => p.kind === "action")

export type PowerToggles = Record<string, boolean>

export function cheatsFromToggles(t: PowerToggles): Cheats {
  return {
    godMode: !!t.godMode,
    infiniteShield: !!t.infiniteShield,
    instantShieldCd: !!t.instantShieldCd,
    thorns: !!t.thorns,
    noVolatile: !!t.noVolatile,
    lifestealHit: !!t.lifestealHit,
    hyperRegen: !!t.hyperRegen,
    oneShot: !!t.oneShot,
    alwaysCrit: !!t.alwaysCrit,
    infinitePierce: !!t.infinitePierce,
    giantBullets: !!t.giantBullets,
    megaMultishot: !!t.megaMultishot,
    wideSpread: !!t.wideSpread,
    rapidFire: !!t.rapidFire,
    autoFire: !!t.autoFire,
    allExplosive: !!t.allExplosive,
    homing: !!t.homing,
    freezeEnemies: !!t.freezeEnemies,
    lowGravity: !!t.lowGravity,
    noSpawns: !!t.noSpawns,
    doubleSpawns: !!t.doubleSpawns,
    fastWaves: !!t.fastWaves,
    maxLuck: !!t.maxLuck,
    rainbow: !!t.rainbow,
    bigPlayer: !!t.bigPlayer,
    tinyPlayer: !!t.tinyPlayer,
    showHitboxes: !!t.showHitboxes,
    damageMult:
      (t.dmgX2 ? 2 : 1) *
      (t.dmgX5 ? 5 : 1) *
      (t.dmgX25 ? 25 : 1) *
      (t.dmgX100 ? 100 : 1),
    coinMult:
      (t.coinX2 ? 2 : 1) *
      (t.coinX5 ? 5 : 1) *
      (t.coinX25 ? 25 : 1) *
      (t.coinX100 ? 100 : 1),
    fireRateMult: (t.fireRateX2 ? 2 : 1) * (t.fireRateX3 ? 3 : 1),
    speedMult: (t.speedX2 ? 2 : 1) * (t.speedX3 ? 3 : 1),
    shieldMult: t.shieldX3 ? 3 : 1,
  }
}
